document.getElementById('send-button').addEventListener('click', function() {
    const userInput = document.getElementById('user-input').value;
    if (userInput) {
        fetch('/api/bot', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ message: userInput })
        })
        .then(response => response.json())
        .then(data => {
            const chatMessages = document.getElementById('chat-messages');
            chatMessages.innerHTML += `<div><strong>You:</strong> ${userInput}</div>`;
            chatMessages.innerHTML += `<div><strong>Bot:</strong> ${data.response}</div>`;
            document.getElementById('user-input').value = '';
        })
        .catch(error => console.error('Error:', error));
    }
});
